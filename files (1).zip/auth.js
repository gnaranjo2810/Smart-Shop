// ============================================================
// SmartShop Auth Module
// Handles: Sign Up, Log In, Log Out, Persistent Session
// Uses localStorage to store user accounts & session data
// ============================================================

const Auth = (() => {
  const USERS_KEY = 'smartshop_users';
  const SESSION_KEY = 'smartshop_session';

  // --- Helpers ---
  function getUsers() {
    return JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
  }
  function saveUsers(users) {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }
  function getSession() {
    return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
  }
  function saveSession(user) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  }
  function clearSession() {
    localStorage.removeItem(SESSION_KEY);
  }

  // --- Core Auth Logic ---
  function signup(name, email, password) {
    const users = getUsers();
    if (users[email]) return { ok: false, error: 'An account with this email already exists.' };
    const user = { name, email, createdAt: new Date().toISOString(), compareList: [], favorites: [] };
    users[email] = { ...user, password }; // store password separately
    saveUsers(users);
    const sessionUser = { ...user };
    saveSession(sessionUser);
    return { ok: true, user: sessionUser };
  }

  function login(email, password) {
    const users = getUsers();
    const found = users[email];
    if (!found) return { ok: false, error: 'No account found with this email.' };
    if (found.password !== password) return { ok: false, error: 'Incorrect password. Please try again.' };
    const sessionUser = { name: found.name, email: found.email, createdAt: found.createdAt, compareList: found.compareList || [], favorites: found.favorites || [] };
    saveSession(sessionUser);
    return { ok: true, user: sessionUser };
  }

  function logout() {
    clearSession();
    updateNavbar(null);
  }

  function currentUser() {
    return getSession();
  }

  // --- UI: Navbar Button ---
  function updateNavbar(user) {
    let btn = document.getElementById('auth-nav-btn');
    if (!btn) return;
    if (user) {
      btn.innerHTML = `
        <span class="auth-avatar">${user.name.charAt(0).toUpperCase()}</span>
        <span class="auth-nav-name">${user.name.split(' ')[0]}</span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
      `;
      btn.classList.add('logged-in');
      btn.onclick = () => openUserMenu();
    } else {
      btn.innerHTML = `
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
        Sign In
      `;
      btn.classList.remove('logged-in');
      btn.onclick = () => openModal('login');
    }
  }

  // --- User Dropdown Menu ---
  function openUserMenu() {
    const existing = document.getElementById('user-dropdown');
    if (existing) { existing.remove(); return; }
    const user = currentUser();
    if (!user) return;

    const dropdown = document.createElement('div');
    dropdown.id = 'user-dropdown';
    dropdown.className = 'user-dropdown';
    dropdown.innerHTML = `
      <div class="user-dropdown-header">
        <div class="user-dropdown-avatar">${user.name.charAt(0).toUpperCase()}</div>
        <div>
          <div class="user-dropdown-name">${user.name}</div>
          <div class="user-dropdown-email">${user.email}</div>
        </div>
      </div>
      <div class="user-dropdown-divider"></div>
      <button class="user-dropdown-item" onclick="Auth.logout(); document.getElementById('user-dropdown')?.remove();">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
        Sign Out
      </button>
    `;
    document.body.appendChild(dropdown);

    // Position below navbar button
    const btn = document.getElementById('auth-nav-btn');
    const rect = btn.getBoundingClientRect();
    dropdown.style.top = (rect.bottom + 8) + 'px';
    dropdown.style.right = (window.innerWidth - rect.right) + 'px';

    // Close on outside click
    setTimeout(() => {
      document.addEventListener('click', function handler(e) {
        if (!dropdown.contains(e.target) && e.target !== btn) {
          dropdown.remove();
          document.removeEventListener('click', handler);
        }
      });
    }, 0);
  }

  // --- Modal Rendering ---
  function openModal(mode = 'login') {
    closeModal();
    const overlay = document.createElement('div');
    overlay.id = 'auth-overlay';
    overlay.className = 'auth-overlay';
    overlay.innerHTML = buildModalHTML(mode);
    document.body.appendChild(overlay);

    // Animate in
    requestAnimationFrame(() => {
      overlay.classList.add('visible');
      overlay.querySelector('.auth-modal').classList.add('visible');
    });

    // Close on backdrop click
    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });

    // Tab switching
    overlay.querySelectorAll('.auth-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        const m = tab.dataset.mode;
        overlay.querySelector('.auth-modal').outerHTML; // keep overlay
        document.getElementById('auth-overlay').innerHTML = buildModalHTML(m);
        attachFormListeners();
        document.querySelectorAll('.auth-tab').forEach(t => t.addEventListener('click', () => {
          openModal(t.dataset.mode);
        }));
      });
    });

    attachFormListeners();
  }

  function closeModal() {
    const overlay = document.getElementById('auth-overlay');
    if (!overlay) return;
    overlay.classList.remove('visible');
    setTimeout(() => overlay.remove(), 300);
  }

  function buildModalHTML(mode) {
    const isLogin = mode === 'login';
    return `
      <div class="auth-modal">
        <button class="auth-close" onclick="Auth.closeModal()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>

        <!-- Logo -->
        <div class="auth-logo">
          <div class="logo-icon" style="width:3rem;height:3rem;">
            <div class="logo-inner">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M5 6L4 20a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2L19 6"></path>
                <path d="M5 6h14"></path>
                <path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"></path>
                <line x1="12" y1="10" x2="12" y2="16"></line>
                <line x1="8" y1="11" x2="16" y2="11"></line>
              </svg>
            </div>
          </div>
        </div>

        <!-- Tabs -->
        <div class="auth-tabs">
          <button class="auth-tab ${isLogin ? 'active' : ''}" data-mode="login">Sign In</button>
          <button class="auth-tab ${!isLogin ? 'active' : ''}" data-mode="signup">Create Account</button>
          <div class="auth-tab-indicator ${!isLogin ? 'right' : ''}"></div>
        </div>

        <!-- Heading -->
        <div class="auth-heading">
          <h2>${isLogin ? 'Welcome back' : 'Join SmartShop'}</h2>
          <p>${isLogin ? 'Sign in to sync your comparisons & saved products across all your devices.' : 'Create a free account to save products, compare across devices, and never lose a deal.'}</p>
        </div>

        <!-- Form -->
        <form id="auth-form" class="auth-form" novalidate>
          ${!isLogin ? `
          <div class="auth-field">
            <label for="auth-name">Full Name</label>
            <div class="auth-input-wrap">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
              <input type="text" id="auth-name" placeholder="Your full name" autocomplete="name" />
            </div>
          </div>
          ` : ''}

          <div class="auth-field">
            <label for="auth-email">Email Address</label>
            <div class="auth-input-wrap">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
              <input type="email" id="auth-email" placeholder="you@example.com" autocomplete="email" />
            </div>
          </div>

          <div class="auth-field">
            <label for="auth-password">Password</label>
            <div class="auth-input-wrap">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
              <input type="password" id="auth-password" placeholder="${isLogin ? 'Your password' : 'Min. 6 characters'}" autocomplete="${isLogin ? 'current-password' : 'new-password'}" />
              <button type="button" class="auth-pw-toggle" tabindex="-1" onclick="Auth.togglePassword()">
                <svg id="pw-eye-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
              </button>
            </div>
          </div>

          <div id="auth-error" class="auth-error hidden"></div>

          <button type="submit" class="auth-submit" id="auth-submit-btn">
            <span id="auth-submit-text">${isLogin ? 'Sign In' : 'Create Account'}</span>
            <div id="auth-spinner" class="auth-spinner hidden"></div>
          </button>
        </form>

        <p class="auth-switch">
          ${isLogin ? "Don't have an account?" : 'Already have an account?'}
          <a href="#" onclick="Auth.openModal('${isLogin ? 'signup' : 'login'}'); return false;">${isLogin ? 'Sign up free' : 'Sign in'}</a>
        </p>
      </div>
    `;
  }

  function attachFormListeners() {
    const form = document.getElementById('auth-form');
    if (!form) return;
    form.addEventListener('submit', handleSubmit);

    // Real-time input focus glow
    form.querySelectorAll('input').forEach(input => {
      input.addEventListener('focus', () => input.closest('.auth-input-wrap').classList.add('focused'));
      input.addEventListener('blur', () => input.closest('.auth-input-wrap').classList.remove('focused'));
    });
  }

  function handleSubmit(e) {
    e.preventDefault();
    const errorEl = document.getElementById('auth-error');
    const submitText = document.getElementById('auth-submit-text');
    const spinner = document.getElementById('auth-spinner');
    const submitBtn = document.getElementById('auth-submit-btn');

    // Check mode
    const isLogin = !!document.getElementById('auth-email') && !document.getElementById('auth-name');
    const email = document.getElementById('auth-email')?.value.trim();
    const password = document.getElementById('auth-password')?.value;
    const name = document.getElementById('auth-name')?.value.trim();

    // Validate
    errorEl.classList.add('hidden');
    if (!email || !password) { showError('Please fill in all fields.'); return; }
    if (!isLogin && !name) { showError('Please enter your name.'); return; }
    if (!isLogin && password.length < 6) { showError('Password must be at least 6 characters.'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showError('Please enter a valid email address.'); return; }

    // Loading state
    submitText.classList.add('hidden');
    spinner.classList.remove('hidden');
    submitBtn.disabled = true;

    // Simulate async (gives UX feedback)
    setTimeout(() => {
      const result = isLogin ? login(email, password) : signup(name, email, password);
      if (!result.ok) {
        submitText.classList.remove('hidden');
        spinner.classList.add('hidden');
        submitBtn.disabled = false;
        showError(result.error);
        return;
      }
      // Success — show tick then close
      submitBtn.innerHTML = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
      submitBtn.style.background = 'var(--success)';
      updateNavbar(result.user);
      setTimeout(() => closeModal(), 700);
    }, 600);
  }

  function showError(msg) {
    const el = document.getElementById('auth-error');
    if (el) { el.textContent = msg; el.classList.remove('hidden'); }
  }

  function togglePassword() {
    const input = document.getElementById('auth-password');
    if (!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    const icon = document.getElementById('pw-eye-icon');
    if (icon) {
      icon.innerHTML = input.type === 'text'
        ? `<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line>`
        : `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>`;
    }
  }

  // --- Init ---
  function init() {
    const user = currentUser();
    updateNavbar(user);
  }

  return { init, openModal, closeModal, logout, currentUser, updateNavbar, togglePassword, openUserMenu };
})();

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => Auth.init());
